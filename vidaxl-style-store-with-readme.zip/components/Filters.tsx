"use client"
import React from "react"
import { useRouter, useSearchParams } from "next/navigation"

export default function Filters() {
  const router = useRouter()
  const sp = useSearchParams()
  const [min, setMin] = React.useState(sp.get("min") ?? "")
  const [max, setMax] = React.useState(sp.get("max") ?? "")
  const [sort, setSort] = React.useState(sp.get("sort") ?? "relevance")

  function apply() {
    const p = new URLSearchParams(sp.toString())
    if (min) p.set("min", min) else p.delete("min")
    if (max) p.set("max", max) else p.delete("max")
    if (sort) p.set("sort", sort)
    router.push("?" + p.toString())
  }
  return (
    <div className="rounded-xl border p-4 bg-white">
      <div className="font-semibold mb-2">Filters</div>
      <div className="grid grid-cols-2 gap-3 text-sm">
        <label className="grid gap-1">
          <span>Min price</span>
          <input value={min} onChange={e=>setMin(e.target.value)} className="border rounded-lg px-2 py-1" inputMode="numeric" />
        </label>
        <label className="grid gap-1">
          <span>Max price</span>
          <input value={max} onChange={e=>setMax(e.target.value)} className="border rounded-lg px-2 py-1" inputMode="numeric" />
        </label>
      </div>
      <div className="mt-3 grid gap-1 text-sm">
        <label className="grid gap-1">
          <span>Sort by</span>
          <select value={sort} onChange={e=>setSort(e.target.value)} className="border rounded-lg px-2 py-1">
            <option value="relevance">Relevance</option>
            <option value="price-asc">Price, Low to High</option>
            <option value="price-desc">Price, High to Low</option>
            <option value="rating-desc">Rating, High to Low</option>
          </select>
        </label>
      </div>
      <button onClick={apply} className="mt-3 rounded-lg bg-emerald-600 text-white px-4 py-2">Apply</button>
    </div>
  )
}
