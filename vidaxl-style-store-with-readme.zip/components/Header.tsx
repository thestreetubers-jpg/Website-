"use client"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Search, ShoppingCart, Heart } from "lucide-react"
import { categories } from "@/lib/data"
import React from "react"

export default function Header() {
  const router = useRouter()
  const [q, setQ] = React.useState("")
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          <Link href="/" className="flex items-center gap-2 shrink-0 font-semibold focus-ring">
            <span className="inline-block w-8 h-8 bg-emerald-600 rounded"></span>
            <span className="hidden sm:inline">Your Store</span>
          </Link>
          <form
            className="relative flex-1 max-w-2xl hidden md:block"
            role="search"
            onSubmit={(e)=>{e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}`)}}
            aria-label="Site search"
          >
            <input
              className="w-full rounded-xl border px-4 py-2 pl-10 outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="Search products"
              value={q}
              onChange={(e)=>setQ(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2" size={18} aria-hidden />
          </form>
          <nav className="flex items-center gap-3">
            <Link href="/account" className="text-sm focus-ring">Account</Link>
            <button aria-label="Wishlist" className="p-2 rounded-lg hover:bg-neutral-100 focus-ring"><Heart size={20} /></button>
            <Link href="/cart" aria-label="Cart" className="relative p-2 rounded-lg hover:bg-neutral-100 focus-ring">
              <ShoppingCart size={20} />
            </Link>
          </nav>
        </div>
      </div>
      <div className="border-t">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-6 overflow-x-auto py-2 text-sm">
            {categories.map(c => (
              <Link key={c.slug} href={`/category/${c.slug}`} className="whitespace-nowrap hover:text-emerald-700 focus-ring">{c.name}</Link>
            ))}
            <Link href="/inspiration" className="ml-auto whitespace-nowrap text-emerald-700 font-medium focus-ring">Get Inspired</Link>
          </div>
        </div>
      </div>
    </header>
  )
}
