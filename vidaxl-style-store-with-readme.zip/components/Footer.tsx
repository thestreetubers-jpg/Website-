import Link from "next/link"
export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-neutral-200 mt-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-4 gap-8">
        <div>
          <p className="font-semibold">Customer Service</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/help" className="hover:underline">Help Center</Link></li>
            <li><Link href="/shipping" className="hover:underline">Shipping and Delivery</Link></li>
            <li><Link href="/returns" className="hover:underline">Returns</Link></li>
            <li><Link href="/payments" className="hover:underline">Payment Options</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold">Business</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/affiliate" className="hover:underline">Affiliate program</Link></li>
            <li><Link href="/dropshipping" className="hover:underline">Dropshipping</Link></li>
            <li><Link href="/careers" className="hover:underline">Careers</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold">Company</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link href="/about" className="hover:underline">About us</Link></li>
            <li><Link href="/sustainability" className="hover:underline">Sustainability</Link></li>
            <li><Link href="/security" className="hover:underline">Security</Link></li>
            <li><Link href="/recalls" className="hover:underline">Product recalls</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-semibold">Get the best deals</p>
          <p className="text-sm text-neutral-400 mt-2">Subscribe to our newsletter for exclusive offers.</p>
          <form className="mt-3 flex gap-2">
            <input type="email" placeholder="Email address" className="flex-1 rounded-xl border border-neutral-700 bg-neutral-800 px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-500" />
            <button className="rounded-xl bg-emerald-600 px-4 py-2 font-medium">Subscribe</button>
          </form>
        </div>
      </div>
      <div className="border-t border-neutral-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4 text-xs text-neutral-400 flex flex-wrap items-center gap-3">
          <p>© {new Date().getFullYear()} Your Store</p>
          <Link href="/privacy" className="hover:underline">Privacy and Cookies</Link>
          <Link href="/terms" className="hover:underline">Terms</Link>
          <Link href="/sitemap" className="hover:underline">Sitemap</Link>
          <button className="ml-auto rounded-lg border border-neutral-700 px-3 py-1">Cookie settings</button>
        </div>
      </div>
    </footer>
  )
}
