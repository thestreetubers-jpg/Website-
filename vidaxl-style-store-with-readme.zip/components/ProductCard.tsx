import Link from "next/link"
import Image from "next/image"
import type { Product } from "@/lib/data"

export default function ProductCard({ p }: { p: Product }) {
  return (
    <Link href={`/product/${p.slug}`} className="group rounded-2xl overflow-hidden bg-white shadow-sm border focus-ring">
      <div className="relative h-48">
        <Image src={p.image + "?auto=format&fit=crop&w=900&q=60"} alt={p.title} fill className="object-cover group-hover:scale-105 transition" />
      </div>
      <div className="p-4">
        <div className="text-sm text-neutral-500">{p.category.replace("-", " ")}</div>
        <h3 className="font-semibold line-clamp-2">{p.title}</h3>
        <div className="mt-2 font-semibold">{p.currency} {p.price.toFixed(2)}</div>
      </div>
    </Link>
  )
}
