import Link from "next/link"

export default function Breadcrumbs({ items }: { items: { label: string, href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-sm text-neutral-600">
      <ol className="flex flex-wrap gap-1 items-center">
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <span>/</span>}
            {it.href ? <Link href={it.href} className="hover:underline">{it.label}</Link> : <span aria-current="page" className="text-neutral-900">{it.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  )
}
