export type Category = {
  slug: string
  name: string
  image: string
}
export type Product = {
  slug: string
  title: string
  description: string
  price: number
  currency: string
  image: string
  category: string
  rating: number
  stock: number
  specs?: Record<string, string>
}

export const categories: Category[] = [
  { slug: "furniture", name: "Furniture", image: "https://images.unsplash.com/photo-1501045661006-fcebe0257c3f" },
  { slug: "home-garden", name: "Home and Garden", image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6" },
  { slug: "hardware", name: "Hardware", image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758" },
  { slug: "sporting-goods", name: "Sporting Goods", image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438" },
  { slug: "pets", name: "Pets", image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b" },
  { slug: "toys", name: "Toys and Games", image: "https://images.unsplash.com/photo-1601758064135-8c3b7d0ae1f9" },
]

export const products: Product[] = [
  {
    slug: "oak-dining-chair",
    title: "Oak Dining Chair",
    description: "Solid oak frame, upholstered seat, durable and comfortable.",
    price: 199.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc",
    category: "furniture", rating: 4.5, stock: 15,
    specs: {"Material": "Oak wood", "Finish": "Natural", "Assembly": "Required"}
  },
  {
    slug: "garden-lounge-set",
    title: "Garden Lounge Set",
    description: "Weather resistant wicker, includes cushions, perfect for patios.",
    price: 899.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1524758631624-e2822e304c36",
    category: "home-garden", rating: 4.2, stock: 8,
    specs: {"Seats": "4", "Cushions": "Included"}
  },
  {
    slug: "impact-drill-500w",
    title: "Impact Drill 500W",
    description: "Reliable drill for home projects, includes carry case.",
    price: 259.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758",
    category: "hardware", rating: 4.0, stock: 20,
    specs: {"Power": "500W", "Chuck": "13mm"}
  },
  {
    slug: "yoga-mat-pro",
    title: "Yoga Mat Pro",
    description: "Non slip surface, comfortable thickness, easy to clean.",
    price: 119.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438",
    category: "sporting-goods", rating: 4.7, stock: 25
  },
  {
    slug: "pet-bed-medium",
    title: "Pet Bed Medium",
    description: "Soft, washable cover, supportive foam for healthy sleep.",
    price: 149.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b",
    category: "pets", rating: 4.3, stock: 30
  },
  {
    slug: "wooden-train-set",
    title: "Wooden Train Set",
    description: "Classic toy, safe paints, encourages creative play.",
    price: 99.00, currency: "AED",
    image: "https://images.unsplash.com/photo-1601758064135-8c3b7d0ae1f9",
    category: "toys", rating: 4.6, stock: 18
  }
]

export function getCategory(slug: string) {
  return categories.find(c => c.slug === slug)
}
export function getProduct(slug: string) {
  return products.find(p => p.slug === slug)
}
export function listByCategory(slug: string) {
  return products.filter(p => p.category === slug)
}
