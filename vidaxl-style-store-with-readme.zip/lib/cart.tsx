"use client"
import React, { createContext, useContext, useMemo, useState } from "react"
import type { Product } from "@/lib/data"

type CartItem = { product: Product, qty: number }
type CartCtx = {
  items: CartItem[]
  add: (p: Product, qty?: number) => void
  remove: (slug: string) => void
  clear: () => void
  total: number
}
const Ctx = createContext<CartCtx | null>(null)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const add = (p: Product, qty = 1) => {
    setItems(prev => {
      const i = prev.findIndex(it => it.product.slug === p.slug)
      if (i >= 0) {
        const copy = [...prev]
        copy[i] = { ...copy[i], qty: copy[i].qty + qty }
        return copy
      }
      return [...prev, { product: p, qty }]
    })
  }
  const remove = (slug: string) => setItems(prev => prev.filter(i => i.product.slug != slug))
  const clear = () => setItems([])
  const total = useMemo(() => items.reduce((s, it) => s + it.product.price * it.qty, 0), [items])
  return <Ctx.Provider value={{ items, add, remove, clear, total }}>{children}</Ctx.Provider>
}

export function useCart() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error("useCart must be used inside CartProvider")
  return ctx
}
