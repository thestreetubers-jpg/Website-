import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { categories, products } from "@/lib/data"
import ProductCard from "@/components/ProductCard"

export default function HomePage() {
  const deals = [
    { title: "Up to 10 percent off, storage, chairs, tables", href: "/deals", img: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc" },
    { title: "Fresh picks just in", href: "/new", img: "https://images.unsplash.com/photo-1524758631624-e2822e304c36" },
  ]

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <section className="grid lg:grid-cols-2 gap-6 py-8">
        <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-emerald-600 to-emerald-800 text-white p-8 flex flex-col justify-between min-h-[320px]">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">Live it up for less</h1>
            <p className="mt-2 text-white/90">Affordable and trendy furniture for every room, delivered free.</p>
          </div>
          <div className="mt-6">
            <Link href="/deals" className="inline-flex items-center gap-2 rounded-xl bg-white text-emerald-700 px-5 py-3 font-medium focus-ring">
              Shop deals <ArrowRight size={18} />
            </Link>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-6">
          {deals.map(d => (
            <Link key={d.title} href={d.href} className="group relative rounded-2xl overflow-hidden bg-white shadow-sm border focus-ring">
              <div className="relative h-48">
                <Image src={d.img + "?auto=format&fit=crop&w=900&q=60"} alt={d.title} fill className="object-cover group-hover:scale-105 transition" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold">{d.title}</h3>
                <span className="inline-flex items-center gap-1 text-sm text-emerald-700">Shop now <ArrowRight size={16} /></span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="py-8">
        <div className="flex items-end justify-between mb-4">
          <h2 className="text-2xl font-bold">Top categories</h2>
          <Link href="/categories" className="text-emerald-700 focus-ring">View all</Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {categories.map(c => (
            <Link key={c.slug} href={`/category/${c.slug}`} className="group rounded-2xl overflow-hidden bg-white shadow-sm border focus-ring">
              <div className="relative h-40">
                <Image src={c.image + "?auto=format&fit=crop&w=900&q=60"} alt={c.name} fill className="object-cover group-hover:scale-105 transition" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold">{c.name}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="py-8 border-y bg-white">
        <div className="flex items-end justify-between mb-4">
          <h2 className="text-2xl font-bold">Shop by room</h2>
          <Link href="/rooms" className="text-emerald-700 focus-ring">Explore</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {["Bedroom","Kitchen","Bathroom","Garden","Kids room","Home office","Balcony","Dining room","Living room","Backyard barbecue"].map(r => (
            <Link key={r} href={`/rooms/${r.toLowerCase().replace(/\s+/g,'-')}`} className="rounded-xl border bg-neutral-50 p-4 hover:bg-neutral-100 text-sm font-medium focus-ring">
              {r}
            </Link>
          ))}
        </div>
      </section>

      <section className="py-8">
        <div className="flex items-end justify-between mb-4">
          <h2 className="text-2xl font-bold">Popular products</h2>
          <Link href="/category/furniture" className="text-emerald-700 focus-ring">Browse all</Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.slice(0,4).map(p => <ProductCard key={p.slug} p={p} />)}
        </div>
      </section>
    </div>
  )
}
