import { categories, products } from "@/lib/data"
export async function GET() {
  const urls = [
    { loc: "/", changefreq: "daily", priority: 1.0 },
    { loc: "/categories", changefreq: "weekly", priority: 0.8 },
    ...categories.map(c => ({ loc: `/category/${c.slug}`, changefreq: "weekly", priority: 0.7 })),
    ...products.map(p => ({ loc: `/product/${p.slug}`, changefreq: "weekly", priority: 0.7 })),
  ]
  const xml = `<?xml version="1.0" encoding="UTF-8"?>` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">` +
    urls.map(u => `<url><loc>${"https://example.com"+u.loc}</loc><changefreq>${u.changefreq}</changefreq><priority>${u.priority}</priority></url>`).join("") +
    `</urlset>`
  return new Response(xml, { headers: { "Content-Type": "application/xml" } })
}
