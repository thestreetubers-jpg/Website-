import Link from "next/link"
import Image from "next/image"
import { categories } from "@/lib/data"

export const metadata = { title: "All categories" }

export default function CategoriesPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-6">All categories</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map(c => (
          <Link key={c.slug} href={`/category/${c.slug}`} className="group rounded-2xl overflow-hidden bg-white shadow-sm border focus-ring">
            <div className="relative h-40">
              <Image src={c.image + "?auto=format&fit=crop&w=900&q=60"} alt={c.name} fill className="object-cover group-hover:scale-105 transition" />
            </div>
            <div className="p-4">
              <h3 className="font-semibold">{c.name}</h3>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
