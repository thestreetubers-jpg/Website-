"use client"
import { useCart } from "@/lib/cart"
import { useRouter } from "next/navigation"

export default function CheckoutPage() {
  const { items, total, clear } = useCart()
  const router = useRouter()
  function placeOrder(e: React.FormEvent) {
    e.preventDefault()
    clear()
    router.push("/thank-you")
  }
  if (items.length === 0) {
    return <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8"><p>Your cart is empty.</p></div>
  }
  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8 grid lg:grid-cols-2 gap-6">
      <form onSubmit={placeOrder} className="rounded-xl border bg-white p-4 grid gap-3">
        <h1 className="text-2xl font-bold">Checkout</h1>
        <label className="grid gap-1 text-sm">
          <span>Full name</span>
          <input className="border rounded-lg px-3 py-2" required />
        </label>
        <label className="grid gap-1 text-sm">
          <span>Phone number, for delivery</span>
          <input className="border rounded-lg px-3 py-2" required />
        </label>
        <label className="grid gap-1 text-sm">
          <span>Address</span>
          <textarea className="border rounded-lg px-3 py-2" required />
        </label>
        <button className="mt-2 rounded-xl bg-emerald-600 text-white px-5 py-3 font-medium">Place order, Cash on delivery</button>
      </form>
      <aside className="rounded-xl border bg-white p-4 h-fit">
        <h2 className="font-semibold">Order summary</h2>
        <div className="mt-2 flex justify-between"><span>Subtotal</span><span className="font-semibold">AED {total.toFixed(2)}</span></div>
        <div className="flex justify-between text-sm text-neutral-600"><span>Shipping</span><span>Free</span></div>
        <div className="mt-3 border-t pt-3 flex justify-between"><span>Total</span><span className="font-semibold">AED {total.toFixed(2)}</span></div>
      </aside>
    </div>
  )
}
