import { notFound } from "next/navigation"
import Image from "next/image"
import Breadcrumbs from "@/components/Breadcrumbs"
import ProductCard from "@/components/ProductCard"
import Filters from "@/components/Filters"
import { getCategory, listByCategory } from "@/lib/data"

type Params = { params: { slug: string }, searchParams: { min?: string, max?: string, sort?: string } }

export function generateMetadata({ params }: { params: { slug: string } }) {
  const cat = getCategory(params.slug)
  return {
    title: cat ? `${cat.name} products` : "Category"
  }
}

export default function CategoryPage({ params, searchParams }: Params) {
  const cat = getCategory(params.slug)
  if (!cat) return notFound()
  let items = listByCategory(cat.slug)
  const min = searchParams.min ? parseFloat(searchParams.min) : undefined
  const max = searchParams.max ? parseFloat(searchParams.max) : undefined
  if (min != null) items = items.filter(p => p.price >= min)
  if (max != null) items = items.filter(p => p.price <= max)
  switch (searchParams.sort) {
    case "price-asc": items = items.sort((a,b)=>a.price-b.price); break
    case "price-desc": items = items.sort((a,b)=>b.price-a.price); break
    case "rating-desc": items = items.sort((a,b)=>b.rating-a.rating); break
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumbs items={[{label: "Home", href:"/"},{label: cat.name}]} />
      <div className="mt-4 grid lg:grid-cols-4 gap-6">
        <aside className="lg:col-span-1">
          <Filters />
          <div className="rounded-xl overflow-hidden mt-4">
            <div className="relative h-40">
              <Image src={cat.image + "?auto=format&fit=crop&w=900&q=60"} alt={cat.name} fill className="object-cover" />
            </div>
          </div>
        </aside>
        <section className="lg:col-span-3">
          <h1 className="text-3xl font-bold mb-4">{cat.name}</h1>
          {items.length === 0 ? <p>No products match your filters.</p> : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map(p => <ProductCard key={p.slug} p={p} />)}
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
