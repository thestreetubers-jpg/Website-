import { products } from "@/lib/data"
import ProductCard from "@/components/ProductCard"

export default function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = (searchParams.q ?? "").toLowerCase()
  const results = q ? products.filter(p => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)) : []
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold">Search results</h1>
      {q ? <p className="text-sm text-neutral-600 mt-1">for "{q}"</p> : <p className="mt-2">Enter a query in the search bar.</p>}
      <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {results.map(p => <ProductCard key={p.slug} p={p} />)}
      </div>
    </div>
  )
}
