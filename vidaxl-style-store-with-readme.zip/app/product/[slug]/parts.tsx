"use client"
import { useCart } from "@/lib/cart"
import { getProduct } from "@/lib/data"
import React from "react"

export function AddToCart({ slug }: { slug: string }) {
  const { add } = useCart()
  const [qty, setQty] = React.useState(1)
  return (
    <div className="mt-6 grid grid-cols-[120px_auto] items-center gap-3">
      <input
        type="number"
        min={1}
        value={qty}
        onChange={e=>setQty(parseInt(e.target.value || "1"))}
        className="border rounded-lg px-3 py-2 w-[120px]"
        aria-label="Quantity"
      />
      <button
        onClick={()=>{
          const p = getProduct(slug)
          if (p) add(p, qty)
        }}
        className="rounded-xl bg-emerald-600 text-white px-5 py-3 font-medium focus-ring"
      >
        Add to cart
      </button>
    </div>
  )
}
