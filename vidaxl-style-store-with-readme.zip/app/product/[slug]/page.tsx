import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import Breadcrumbs from "@/components/Breadcrumbs"
import { getProduct } from "@/lib/data"
import { AddToCart } from "./parts"

export function generateStaticParams() {
  return []
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const product = getProduct(params.slug)
  return {
    title: product ? product.title : "Product",
    description: product?.description
  }
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProduct(params.slug)
  if (!product) return notFound()
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumbs items={[{label:"Home", href:"/"}, {label: product.category.replace("-", " "), href: `/category/${product.category}`}, {label: product.title}]} />
      <div className="grid lg:grid-cols-5 gap-8 mt-4">
        <div className="lg:col-span-3">
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-white border">
            <Image src={product.image + "?auto=format&fit=crop&w=1200&q=60"} alt={product.title} fill className="object-cover" />
          </div>
        </div>
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold">{product.title}</h1>
          <div className="mt-2 text-sm text-neutral-600">Rating {product.rating} out of 5</div>
          <div className="mt-4 text-2xl font-bold">{product.currency} {product.price.toFixed(2)}</div>
          <p className="mt-4 text-neutral-700">{product.description}</p>
          <AddToCart slug={product.slug} />
          {product.specs && (
            <div className="mt-6">
              <h2 className="font-semibold">Specifications</h2>
              <table className="mt-2 w-full text-sm">
                <tbody>
                  {Object.entries(product.specs).map(([k,v]) => (
                    <tr key={k} className="border-t">
                      <td className="py-2 pr-4 text-neutral-600 w-40">{k}</td>
                      <td className="py-2">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-6 text-sm">
            <p>Need help, <Link href="/help" className="text-emerald-700 underline">visit support</Link></p>
          </div>
        </div>
      </div>
      <script type="application/ld+json" suppressHydrationWarning>
        {JSON.stringify({
          "@context":"https://schema.org",
          "@type":"Product",
          "name": product.title,
          "image": product.image,
          "description": product.description,
          "sku": product.slug,
          "offers": {
            "@type": "Offer",
            "priceCurrency": product.currency,
            "price": product.price.toFixed(2),
            "availability": product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": product.rating,
            "reviewCount": 10
          }
        })}
      </script>
    </div>
  )
}

export const dynamic = "force-static"
