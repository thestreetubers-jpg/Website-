import Link from "next/link"

export default function ThankYou() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16 text-center">
      <h1 className="text-3xl font-bold">Thank you for your order</h1>
      <p className="mt-2 text-neutral-700">We will contact you shortly to confirm delivery.</p>
      <Link href="/" className="mt-6 inline-block rounded-xl bg-emerald-600 text-white px-5 py-3 font-medium">Continue shopping</Link>
    </div>
  )
}
