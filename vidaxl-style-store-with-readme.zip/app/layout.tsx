import type { Metadata } from "next"
import "./globals.css"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import { CartProvider } from "@/lib/cart"

export const metadata: Metadata = {
  title: "Your Store, Live it up for less",
  description: "Affordable and trendy products, free delivery, phone support, and secure payments.",
  metadataBase: new URL("https://example.com")
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-neutral-50 text-neutral-900">
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  )
}
