"use client"
import { useCart } from "@/lib/cart"
import Link from "next/link"

export default function CartPage() {
  const { items, remove, total, clear } = useCart()
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-6">Your cart</h1>
      {items.length === 0 ? (
        <p>Your cart is empty, <Link href="/categories" className="underline text-emerald-700">browse products</Link></p>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 rounded-xl border bg-white p-4">
            <ul className="divide-y">
              {items.map(it => (
                <li key={it.product.slug} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium">{it.product.title}</div>
                    <div className="text-sm text-neutral-600">{it.qty} × {it.product.currency} {it.product.price.toFixed(2)}</div>
                  </div>
                  <button onClick={()=>remove(it.product.slug)} className="text-sm underline">Remove</button>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border bg-white p-4 h-fit">
            <div className="flex justify-between"><span>Subtotal</span><span className="font-semibold">AED {total.toFixed(2)}</span></div>
            <p className="text-xs text-neutral-600 mt-2">Shipping is free on all products.</p>
            <Link href="/checkout" className="mt-4 block rounded-xl bg-emerald-600 text-white px-5 py-3 text-center font-medium">Checkout</Link>
            <button onClick={clear} className="mt-3 w-full rounded-xl border px-5 py-3 text-center">Clear cart</button>
          </div>
        </div>
      )}
    </div>
  )
}
