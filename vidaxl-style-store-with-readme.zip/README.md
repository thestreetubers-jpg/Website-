# Your Store, Next.js storefront

This is a complete Next.js 14, TypeScript, and Tailwind storefront scaffold, ready to deploy.

## Quick start, no coding

### Option 1, publish directly with Vercel
1. Create free accounts on GitHub and Vercel.
2. On GitHub, create a new repository, click **Add file, Upload files**, and upload all files from this folder.
3. On Vercel, click **New Project**, **Import Git Repository**, pick your GitHub repo, then **Deploy** with defaults.
4. Vercel will give you a live URL, for example `https://your-store.vercel.app`.
5. To add your own domain later, open the project in Vercel, **Settings, Domains**, and follow the instructions.

### Option 2, run on your computer then deploy
1. Install Node.js LTS from nodejs.org.
2. Open a terminal in this folder, then run:
   ```bash
   npm install
   npm run dev
   ```
   Visit http://localhost:3000
3. Build a production version:
   ```bash
   npm run build
   npm start
   ```

## Where to change text, images, and products

- Site title and description, `app/layout.tsx`
- Header logo text, `components/Header.tsx`
- Footer links, `components/Footer.tsx`
- Categories and products, `lib/data.ts` (edit names, prices, image links)
- Homepage hero and tiles, `app/page.tsx`
- Checkout wording, `app/checkout/page.tsx`

## Notes

- Product pages include JSON-LD structured data for better SEO.
- `app/sitemap.xml/route.ts` generates a sitemap.
- `app/robots.txt` is included.
- Remote images are allowed from Unsplash by default in `next.config.mjs`.
- To switch to your own images, replace the URLs in `lib/data.ts` and pages.

## Support

If you need help, share your brand name, logo, and the list of products or services, and I will prepare an updated package for you.
